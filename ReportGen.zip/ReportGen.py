import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from PIL import ImageTk, Image
import pandas as pd
import matplotlib.pyplot as plt
from math import pi
import os
import json
from tkinter import ttk
import threading
import time
import openai

openai.api_key = "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"  # Replace with your actual API key

# Initial subject/topic structure
subjects = {
    "Math": ["Addition", "More/Fewer", "Shapes"],
    "Science": ["Observation", "Sorting"],
    "Social": ["Emotions", "Community Roles"],
    "Language": ["Vocabulary", "Following Directions"],
    "Writing": ["Tracing", "Copying"],
    "Motor Skills": ["Cutting", "Lacing"]
}

slider_range = {"min": 0, "max": 3}
students_file = "reports/students.json"


def load_students():
    if os.path.exists(students_file):
        with open(students_file, "r", encoding="utf-8") as f:
            data = json.load(f)
            # Fallback if it's accidentally a list from before
            if isinstance(data, list):
                return {name: {"age": "", "class": ""} for name in data}
            return data
    return {}

def save_students(students):
    with open(students_file, "w", encoding="utf-8") as f:
        json.dump(students, f, indent=2)

class AssessmentApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Pre-K Student Assessment")
        self.entries = {}
        self.students = load_students()

        self.student_name_var = tk.StringVar()
        self.student_age_var = tk.StringVar()
        self.student_class_var = tk.StringVar()
        self.instructions_var = tk.StringVar()

        self.top_frame = ttk.Frame(root)
        self.top_frame.pack(fill="x", padx=10, pady=5)
        ttk.Label(self.top_frame, text="Student Name:").pack(side="left")
        ttk.Entry(self.top_frame, textvariable=self.student_name_var).pack(side="left", fill="x", expand=False)
        ttk.Label(self.top_frame, text="Age:").pack(side="left", padx=(10, 0))
        ttk.Entry(self.top_frame, textvariable=self.student_age_var, width=5).pack(side="left")
        ttk.Label(self.top_frame, text="Class:").pack(side="left", padx=(10, 0))
        ttk.Entry(self.top_frame, textvariable=self.student_class_var, width=30).pack(side="left")
        ttk.Button(self.top_frame, text="Edit Subjects", command=self.edit_subjects).pack(side="right")
        ttk.Button(self.top_frame, text="Settings", command=self.edit_settings).pack(side="right", padx=5)

        self.body_frame = ttk.Frame(root)
        self.body_frame.pack(fill="both", expand=True)

        self.student_frame = ttk.Frame(self.body_frame, width=120)
        self.student_frame.pack(side="left", fill="y", padx=5, pady=5)
        self.student_listbox = tk.Listbox(self.student_frame)
        self.student_listbox.pack(fill="both", expand=True)
        self.student_listbox.bind("<<ListboxSelect>>", self.load_selected_student)
        self.refresh_student_list()

        self.form_frame = ttk.Frame(self.body_frame)
        self.form_frame.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        self.report_frame = ttk.Frame(self.body_frame)
        self.report_frame.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        self.image_label = ttk.Label(self.report_frame)
        self.image_label.pack()
        self.response_box = tk.Text(self.report_frame, height=10, wrap="word")
        self.response_box.pack(fill="both", expand=True)

        self.chat_frame = ttk.Frame(self.body_frame, width=200)
        self.chat_frame.pack(side="left", fill="y", padx=5, pady=5)
        ttk.Label(self.chat_frame, text="Instructions for ChatGPT (report focus only):").pack(anchor="w")
        self.chatgpt_entry = tk.Text(self.chat_frame, height=10, wrap="word")
        self.chatgpt_entry.pack(fill="both", expand=True)
        self.radar_label = ttk.Label(self.chat_frame)
        self.radar_label.pack(pady=5)

        self.build_form()

        ttk.Button(root, text="Generate Report", command=self.run_report_thread).pack(pady=10)
        self.progress = ttk.Progressbar(self.body_frame, orient="horizontal", mode="indeterminate", length=300)
        self.progress.pack(pady=5)


    def build_form(self):
        for widget in self.form_frame.winfo_children():
            widget.destroy()

        self.entries = {}
        row = 0
        for subject, topics in subjects.items():
            ttk.Label(self.form_frame, text=subject, font=("Arial", 10, "bold")).grid(row=row, column=0, sticky="w", pady=(10, 0))
            row += 1
            for topic in topics:
                ttk.Label(self.form_frame, text=topic).grid(row=row, column=0, sticky="w")
                var = tk.DoubleVar(value=slider_range["min"])
                self.entries[f"{subject}:{topic}"] = var

                frame = ttk.Frame(self.form_frame)
                frame.grid(row=row, column=1, sticky="ew")

                scale = tk.Scale(frame, from_=slider_range["min"], to=slider_range["max"],
                                 orient="horizontal", variable=var, resolution=0.5, showvalue=False)
                scale.pack(side="left", fill="x", expand=True)

                value_label = ttk.Label(frame, textvariable=var, width=5)
                value_label.pack(side="right")

                row += 1
    
    def run_report_thread(self):
        self.progress.start()
        self.root.update_idletasks()
        thread = threading.Thread(target=self.generate_report)
        thread.start()

    def refresh_student_list(self):
        self.student_listbox.delete(0, tk.END)
        for name in self.students:
            self.student_listbox.insert(tk.END, name)

    def refresh_subject_list(self, listbox):
        listbox.delete(0, tk.END)
        for subject in subjects.keys():
            listbox.insert(tk.END, subject)

    def load_selected_student(self, event):
        selected = self.student_listbox.curselection()
        if selected:
            name = self.student_listbox.get(selected[0])
            self.student_name_var.set(name)

            # Also load age and class if they exist
            if name in self.students:
                self.student_age_var.set(self.students[name].get("age", ""))
                self.student_class_var.set(self.students[name].get("class", ""))

    def edit_subjects(self):
            editor = tk.Toplevel(self.root)
            editor.title("Edit Subjects & Topics")
            editor.geometry("300x400")

            box = tk.Listbox(editor)
            box.pack(fill="both", expand=True, padx=10, pady=10)
            self.refresh_subject_list(box)

            def add_subject():
                name = simpledialog.askstring("New Subject", "Enter subject name:", parent=editor)
                if name and name not in subjects:
                    subjects[name] = []
                    self.refresh_subject_list(box)

            def add_topic():
                selected = box.curselection()
                if selected:
                    subject = box.get(selected[0])
                    name = simpledialog.askstring("New Topic", f"Add topic to '{subject}':", parent=editor)
                    if name:
                        subjects[subject].append(name)
                        self.refresh_subject_list(box)

            def delete():
                selected = box.curselection()
                if selected:
                    subject = box.get(selected[0])
                    if messagebox.askyesno("Confirm", f"Delete subject '{subject}'?"):
                        del subjects[subject]
                        self.refresh_subject_list(box)

            btn_frame = ttk.Frame(editor)
            btn_frame.pack(pady=5)
            ttk.Button(btn_frame, text="Add Subject", command=add_subject).pack(side="left", padx=5)
            ttk.Button(btn_frame, text="Add Topic", command=add_topic).pack(side="left", padx=5)
            ttk.Button(btn_frame, text="Delete", command=delete).pack(side="left", padx=5)

            ttk.Button(editor, text="Done", command=lambda: [self.build_form(), editor.destroy()]).pack(pady=10)


    def edit_settings(self):
        settings = tk.Toplevel(self.root)
        settings.title("Slider Settings")
        settings.geometry("250x150")

        min_val = tk.IntVar(value=slider_range["min"])
        max_val = tk.IntVar(value=slider_range["max"])

        ttk.Label(settings, text="Minimum Value:").pack(pady=(10, 0))
        ttk.Entry(settings, textvariable=min_val).pack(pady=5)
        ttk.Label(settings, text="Maximum Value:").pack()
        ttk.Entry(settings, textvariable=max_val).pack(pady=5)

        def save():
            slider_range["min"] = min_val.get()
            slider_range["max"] = max_val.get()
            self.build_form()
            settings.destroy()

        ttk.Button(settings, text="Apply", command=save).pack(pady=10)

    def generate_report(self):
        self.progress.start()
        self.root.update_idletasks()
        time.sleep(3) 
        student = self.student_name_var.get().strip()
        if not student:
            messagebox.showerror("Error", "Please enter a student name.")
            return

        age = self.student_age_var.get().strip()
        klass = self.student_class_var.get().strip()

        self.students[student] = {
            "age": age,
            "class": klass
        }
        save_students(self.students)
        self.refresh_student_list()


        data = {}
        for key, var in self.entries.items():
            subject, topic = key.split(":")
            if subject not in data:
                data[subject] = {}
            data[subject][topic] = var.get()

        # Radar chart data
        categories = list(data.keys())
        values = [sum(topic.values()) / len(topic) for topic in data.values()]
        values += values[:1]
        angles = [n / float(len(categories)) * 2 * pi for n in range(len(categories))]
        angles += angles[:1]

        plt.figure(figsize=(4, 4))
        ax = plt.subplot(111, polar=True)
        plt.xticks(angles[:-1], categories)
        ax.plot(angles, values, linewidth=1, linestyle='solid')
        ax.fill(angles, values, 'skyblue', alpha=0.4)
        plt.title(f"{student} Overview")
        chart_path = f"reports/{student}_radar_chart.png"
        os.makedirs("reports", exist_ok=True)
        plt.savefig(chart_path)
        plt.close()

        img = Image.open(chart_path)
        img = img.resize((200, 200))
        self.radar_img = ImageTk.PhotoImage(img)
        self.radar_label.config(image=self.radar_img)

        flattened = {f"{k}:{t}": v for k, d in data.items() for t, v in d.items()}
        instruction = self.chatgpt_entry.get("1.0", tk.END).strip()
        age = self.student_age_var.get().strip()
        klass = self.student_class_var.get().strip()

        report_prompt = (
            f"Student: {student}\n"
            f"Age: {age}\n"
            f"Class: {klass}\n"
            f"Assessment Data: {flattened}\n"
            f"Instructions: {instruction}\n"
            f"Write a bilingual English-Chinese report. Please make sure the report is pleasing. Don't write the results but instead report how they did in each area. "
            f"Make sure you only include one or two lines of how they can improve their skills. Make sure you have a friendly tone. Write your report in two paragraphs."
        )

        try:
            client = openai.OpenAI(api_key=openai.api_key)
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": report_prompt}],
                temperature=0.7
            )
            report_txt = response.choices[0].message.content.strip()
        except Exception as e:
            report_txt = f"Failed to generate report using ChatGPT.\nError: {e}"
        finally:
            self.progress.stop()

        self.response_box.delete("1.0", tk.END)
        self.response_box.insert(tk.END, report_txt)

        with open(f"reports/{student}_report.txt", "w", encoding="utf-8") as f:
            f.write(report_txt)

        messagebox.showinfo("Success", f"Report saved for {student}.")

if __name__ == '__main__':
    root = tk.Tk()
    app = AssessmentApp(root)
    root.mainloop()